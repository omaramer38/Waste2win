document.querySelector('.btn-confirm').addEventListener('click', () => {
  alert('Order confirmed!');
});
