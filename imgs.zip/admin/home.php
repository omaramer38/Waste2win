<?php

include("inc/check_role.php");
include("../fun/alert.php");

echo "<h1>مرحبًا بك في صفحة العامل</h1>";


?>